def fun():
    print("do some thing")

fun()
